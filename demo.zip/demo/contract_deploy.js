const Web3 = require("web3")
const host="https://exchaintestrpc.okex.org"
if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    web3 = new Web3(new Web3.providers.HttpProvider(host));
}
const fromAddr='fromAddr'
const privateKey ='privateKey';
const bytecode='60806040523480156100115760006000fd5b50610017565b61012b806100266000396000f3fe608060405234801560' +
    '105760006000fd5b5060043610602c5760003560e01c80630c49c36c14603257602c565b60006000fd5b603860b1565b6040518' +
    '080602001828103825283818151815260200191508051906020019080838360005b8381101560775780820151818401525b6020' +
    '81019050605d565b50505050905090810190601f16801560a35780820380516001836020036101000a031916815260200191505' +
    'b509250505060405180910390f35b60606040518060400160405280600b81526020017f48656c6c6f20576f726c640000000000' +
    '00000000000000000000000000000000815260200150905060f2565b9056fea26469706673582212205fa898a0332c5ba79ffeb' +
    'eb693abe0c217822639d0affa49096ff31284c9981264736f6c63430006000033'

//合约部署函数
function deploy() {
    web3.eth.getTransactionCount(fromAddr, function (error, result) {
        var rawTx = {
            nonce: result,
            gasLimit: web3.utils.toHex(1000000),
            gasPrice: web3.utils.toHex(web3.utils.toWei('10', 'gwei')),
            data: '0x' + bytecode
        }
        //离线签名
        const signedTransaction = web3.eth.accounts.signTransaction(rawTx,privateKey);
        //广播交易
        signedTransaction.then((signedTransaction) => {
            const rawTransaction=signedTransaction.rawTransaction
            web3.eth.sendSignedTransaction(rawTransaction,(err,hash)=>{
                if(!err)
                    console.log('txHash:',hash)
                else
                    console.log(err)
            });
        });
    });
}
deploy()
