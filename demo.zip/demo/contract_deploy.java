package com.xq.okexchain;

import org.web3j.crypto.*;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Numeric;
import java.io.IOException;
import java.math.BigInteger;
import java.util.concurrent.ExecutionException;

public class OkexDeploy {
    public static void main(String[]args) throws IOException, CipherException, ExecutionException, InterruptedException {

        String url="https://exchaintestrpc.okex.org";
        Web3j web3j = Web3j.build(new HttpService(url));
        String privateKey="privateKey";
        //发送方地址
        String from = "from";
        String data="0x60806040526000600060005090905534801561001b5760006000fd5b50610021565b6102bc806100306000396000f3fe60806040523480156100115760006000fd5b50600436106100465760003560e01c80631003e2d21461004c5780636deebae31461007b5780638ada066e1461008557610046565b60006000fd5b610079600480360360208110156100635760006000fd5b81019080803590602001909291905050506100a3565b005b610083610132565b005b61008d610274565b6040518082815260200191505060405180910390f35b806000600050540160006000508190909055507f64a55044d1f2eddebe1b90e8e2853e8e96931cefadbfa0b2ceb34bee360619416000600050546040518082815260200191505060405180910390a17f938d2ee5be9cfb0f7270ee2eff90507e94b37625d9d2b3a61c97d30a4560b8296000600050546040518082815260200191505060405180910390a15b50565b6000600060005054116040518060400160405280600f81526020017f434f554e5445525f544f4f5f4c4f57000000000000000000000000000000000081526020015090151561021d576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b838110156101e25780820151818401525b6020810190506101c6565b50505050905090810190601f16801561020f5780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b5060006000818150548092919060019003919050909055507f938d2ee5be9cfb0f7270ee2eff90507e94b37625d9d2b3a61c97d30a4560b8296000600050546040518082815260200191505060405180910390a15b565b60006000600050549050610283565b9056fea26469706673582212206b619c15c776ee7e72c5abdade8587993c73bb94ff23009cb23e9c327416414f64736f6c63430006000033";
        BigInteger nonce = web3j.ethGetTransactionCount(from,DefaultBlockParameterName.PENDING).send().getTransactionCount();
        //支付的矿工费
        BigInteger gasPrice = web3j.ethGasPrice().send().getGasPrice();
        BigInteger gasLimit = new BigInteger("210000");
        RawTransaction rt=RawTransaction.createContractTransaction(
                nonce,
                gasPrice,
                gasLimit,
                BigInteger.ZERO,
                data);
        Credentials credentials = Credentials.create(privateKey);
        byte[] signMessage = TransactionEncoder.signMessage(rt, credentials);
        String hash = web3j.ethSendRawTransaction(Numeric.toHexString(signMessage)).sendAsync().get().getTransactionHash();
        System.out.println("hash:" + hash);
    }
}
